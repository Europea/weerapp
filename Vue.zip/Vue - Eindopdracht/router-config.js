import Vue from 'vue';
import VueRouter from 'vue-router';

// Importeer de componenten voor je routes
import Home from './components/Home.vue';
import Weather from './components/Weather.vue';

Vue.use(VueRouter);

const routes = [
  { path: '/', component: Home },
  { path: '/weather', component: Weather }
];

const router = new VueRouter({
  routes
});

new Vue({
  el: '#app',
  router
});